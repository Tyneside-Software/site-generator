/**
 * Server-side product catalogue.
 * Prices are authoritative (pence) — never trust client-sent amounts.
 */

const PRODUCTS = [
  {
    id: "t14s-339",
    dealId: 1,
    name: "ThinkPad T14s Gen 2 — 256GB SSD",
    description: "i7-1185G7 · 32GB RAM · 256GB SSD · Windows 11 Pro",
    storage: 256,
    os: "Windows 11 Pro",
    pricePence: 33900,
    currency: "gbp",
    badge: "steal",
    badgeLabel: "Excellent value",
    rating: 5,
    tag: "buy",
    valueRank: 1,
    verdict: "Excellent value if you don’t mind upgrading the SSD later.",
    note: "Upgrade SSD later for more room",
  },
  {
    id: "t14s-416",
    dealId: 2,
    name: "ThinkPad T14s Gen 2 — 512GB SSD",
    description: "i7-1185G7 · 32GB RAM · 512GB SSD · Windows 11 Pro",
    storage: 512,
    os: "Windows 11 Pro",
    pricePence: 41600,
    currency: "gbp",
    badge: "best",
    badgeLabel: "Best overall",
    rating: 5,
    tag: "buy",
    valueRank: 0,
    verdict: "Best overall value. Great balance of price and storage.",
    note: "Recommended pick for most buyers",
  },
  {
    id: "t14s-430",
    dealId: 3,
    name: "ThinkPad T14s Gen 2 — 512GB SSD",
    description: "i7-1185G7 · 32GB RAM · 512GB SSD",
    storage: 512,
    os: "Not listed",
    pricePence: 43000,
    currency: "gbp",
    badge: "good",
    badgeLabel: "Good buy",
    rating: 4,
    tag: "buy",
    valueRank: 2,
    verdict: "Still a good buy if in excellent condition.",
    note: "Confirm condition before buying",
  },
  {
    id: "t14s-500",
    dealId: 4,
    name: "ThinkPad T14s Gen 2 — 512GB SSD",
    description: "i7-1185G7 · 32GB RAM · 512GB SSD",
    storage: 512,
    os: "Not listed",
    pricePence: 50000,
    currency: "gbp",
    badge: "caution",
    badgeLabel: "Warranty needed",
    rating: 3,
    tag: "caution",
    valueRank: 3,
    verdict: "Only worth buying if it includes a warranty and excellent battery health.",
    note: "Require warranty + battery health",
  },
  {
    id: "t14s-530",
    dealId: 5,
    name: "ThinkPad T14s Gen 2 — 512GB SSD",
    description: "i7-1185G7 · 32GB RAM · 512GB SSD",
    storage: 512,
    os: "Not listed",
    pricePence: 53000,
    currency: "gbp",
    badge: "skip",
    badgeLabel: "Overpriced",
    rating: 2,
    tag: "skip",
    valueRank: 4,
    verdict: "Overpriced unless it is in near-new condition.",
    note: "Consider Gen 3 / X1 Carbon instead",
  },
];

function listProducts() {
  return PRODUCTS.map((p) => ({
    id: p.id,
    dealId: p.dealId,
    name: p.name,
    description: p.description,
    storage: p.storage,
    os: p.os,
    price: p.pricePence / 100,
    pricePence: p.pricePence,
    currency: p.currency,
    badge: p.badge,
    badgeLabel: p.badgeLabel,
    rating: p.rating,
    tag: p.tag,
    valueRank: p.valueRank,
    verdict: p.verdict,
    note: p.note,
  }));
}

function getProduct(id) {
  return PRODUCTS.find((p) => p.id === id) || null;
}

module.exports = { listProducts, getProduct, PRODUCTS };
