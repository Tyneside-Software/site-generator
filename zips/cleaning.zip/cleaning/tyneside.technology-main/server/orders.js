const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "..", "data");
const ORDERS_FILE = path.join(DATA_DIR, "orders.json");

function ensureStore() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(ORDERS_FILE)) {
    fs.writeFileSync(ORDERS_FILE, "[]\n", "utf8");
  }
}

function readOrders() {
  ensureStore();
  try {
    const raw = fs.readFileSync(ORDERS_FILE, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("[orders] Failed to read store:", err.message);
    return [];
  }
}

function writeOrders(orders) {
  ensureStore();
  fs.writeFileSync(ORDERS_FILE, JSON.stringify(orders, null, 2) + "\n", "utf8");
}

function generateOrderRef() {
  const stamp = new Date().toISOString().slice(0, 10).replace(/-/g, "");
  const rand = crypto.randomBytes(3).toString("hex").toUpperCase();
  return `TYN-${stamp}-${rand}`;
}

/**
 * Create a pending order when checkout starts.
 */
function createPendingOrder({
  productId,
  productName,
  quantity,
  unitAmountPence,
  currency,
  stripeSessionId,
}) {
  const orders = readOrders();
  const order = {
    id: crypto.randomUUID(),
    orderRef: generateOrderRef(),
    status: "pending",
    productId,
    productName,
    quantity,
    unitAmountPence,
    totalPence: unitAmountPence * quantity,
    currency: currency || "gbp",
    customerName: null,
    customerEmail: null,
    stripeSessionId: stripeSessionId || null,
    stripePaymentIntentId: null,
    whatsappNotified: false,
    whatsappError: null,
    createdAt: new Date().toISOString(),
    paidAt: null,
  };
  orders.push(order);
  writeOrders(orders);
  return order;
}

function findBySessionId(sessionId) {
  return readOrders().find((o) => o.stripeSessionId === sessionId) || null;
}

function findByOrderRef(orderRef) {
  return readOrders().find((o) => o.orderRef === orderRef) || null;
}

function updateOrder(orderId, patch) {
  const orders = readOrders();
  const idx = orders.findIndex((o) => o.id === orderId);
  if (idx === -1) return null;
  orders[idx] = { ...orders[idx], ...patch, updatedAt: new Date().toISOString() };
  writeOrders(orders);
  return orders[idx];
}

/**
 * Mark paid from Stripe webhook. Idempotent if already paid.
 */
function markPaidFromSession(session) {
  let order = findBySessionId(session.id);

  if (!order && session.metadata?.orderRef) {
    order = findByOrderRef(session.metadata.orderRef);
  }

  if (!order) {
    // Fallback: create from session metadata if store was wiped
    const qty = Math.max(1, Number(session.metadata?.quantity || 1));
    const unit = Number(
      session.metadata?.unitAmountPence ||
        (session.amount_total != null ? Math.round(session.amount_total / qty) : 0)
    );
    order = createPendingOrder({
      productId: session.metadata?.productId || "unknown",
      productName: session.metadata?.productName || "Laptop",
      quantity: qty,
      unitAmountPence: unit,
      currency: session.currency || "gbp",
      stripeSessionId: session.id,
    });
    if (session.metadata?.orderRef) {
      order = updateOrder(order.id, { orderRef: session.metadata.orderRef });
    }
  }

  if (order.status === "paid") {
    return { order, alreadyPaid: true };
  }

  const customerName =
    session.customer_details?.name ||
    session.metadata?.customerName ||
    "—";
  const customerEmail =
    session.customer_details?.email ||
    session.customer_email ||
    "—";

  const quantity = Number(
    session.metadata?.quantity || order.quantity || 1
  );
  const totalPence = session.amount_total ?? order.totalPence;

  const updated = updateOrder(order.id, {
    status: "paid",
    paidAt: new Date().toISOString(),
    customerName,
    customerEmail,
    quantity,
    totalPence,
    stripeSessionId: session.id,
    stripePaymentIntentId:
      typeof session.payment_intent === "string"
        ? session.payment_intent
        : session.payment_intent?.id || null,
  });

  return { order: updated, alreadyPaid: false };
}

module.exports = {
  createPendingOrder,
  findBySessionId,
  findByOrderRef,
  updateOrder,
  markPaidFromSession,
  readOrders,
};
