require("dotenv").config();

const path = require("path");
const express = require("express");
const Stripe = require("stripe");
const { listProducts, getProduct } = require("./catalog");
const {
  createPendingOrder,
  updateOrder,
  markPaidFromSession,
} = require("./orders");
const { notifyNewOrder } = require("./whatsapp");

const PORT = Number(process.env.PORT) || 3000;
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(
  /\/$/,
  ""
);

function stripeKeyLooksValid(key) {
  if (!key || typeof key !== "string") return false;
  if (!/^sk_(test|live)_/.test(key)) return false;
  // Reject common placeholders from .env.example
  if (/paste|your[_-]?key|xxx|changeme|here$/i.test(key)) return false;
  // Real Stripe secret keys are long
  if (key.length < 30) return false;
  return true;
}

const stripeSecretKey = process.env.STRIPE_SECRET_KEY || "";
if (!stripeKeyLooksValid(stripeSecretKey)) {
  console.warn(
    "[stripe] STRIPE_SECRET_KEY is missing or still a placeholder. " +
      "Paste a real key from https://dashboard.stripe.com/apikeys into .env"
  );
}

const stripe = stripeKeyLooksValid(stripeSecretKey)
  ? new Stripe(stripeSecretKey)
  : null;

const app = express();
const rootDir = path.join(__dirname, "..");

// Stripe webhooks need the raw body for signature verification
app.post(
  "/api/webhooks/stripe",
  express.raw({ type: "application/json" }),
  async (req, res) => {
    if (!stripe) {
      return res.status(503).send("Stripe not configured");
    }

    const sig = req.headers["stripe-signature"];
    const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

    let event;
    try {
      if (!webhookSecret) {
        throw new Error("STRIPE_WEBHOOK_SECRET is not set");
      }
      event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
    } catch (err) {
      console.error("[stripe] Webhook signature verification failed:", err.message);
      return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === "checkout.session.completed") {
      const session = event.data.object;

      // Only act on paid sessions (one-time payments)
      if (session.payment_status !== "paid" && session.status !== "complete") {
        console.log(
          "[stripe] Session completed but not paid yet:",
          session.id,
          session.payment_status
        );
        return res.json({ received: true });
      }

      try {
        const { order, alreadyPaid } = markPaidFromSession(session);

        if (alreadyPaid) {
          console.log("[orders] Already paid:", order.orderRef);
          return res.json({ received: true, orderRef: order.orderRef });
        }

        console.log("[orders] Marked paid:", order.orderRef);

        // WhatsApp is best-effort — never fail the webhook
        try {
          const result = await notifyNewOrder(order);
          if (result.ok) {
            updateOrder(order.id, {
              whatsappNotified: true,
              whatsappError: null,
            });
          } else {
            updateOrder(order.id, {
              whatsappNotified: false,
              whatsappError: result.error || "unknown",
            });
            console.error(
              "[orders] WhatsApp notification failed; order remains paid:",
              result.error
            );
          }
        } catch (waErr) {
          updateOrder(order.id, {
            whatsappNotified: false,
            whatsappError: waErr.message,
          });
          console.error(
            "[orders] WhatsApp threw; order remains paid:",
            waErr.message
          );
        }
      } catch (err) {
        console.error("[orders] Failed to process checkout.session.completed:", err);
        // Still 200 so Stripe does not hammer retries for app bugs; log for ops
        return res.status(500).json({ error: "Order processing failed" });
      }
    }

    res.json({ received: true });
  }
);

// JSON for the rest of the API
app.use(express.json());

// Health
app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    stripe: Boolean(stripe),
    whatsappConfigured: Boolean(
      process.env.WHATSAPP_TOKEN &&
        process.env.WHATSAPP_PHONE_NUMBER_ID &&
        process.env.WHATSAPP_TO
    ),
  });
});

// Catalogue for the storefront
app.get("/api/products", (_req, res) => {
  res.json({ products: listProducts() });
});

/**
 * Create a Stripe Checkout Session for a specific laptop.
 * Body: { productId: string, quantity?: number }
 */
app.post("/api/create-checkout-session", async (req, res) => {
  if (!stripe) {
    return res.status(503).json({
      error:
        "Stripe is not configured. Open .env and set STRIPE_SECRET_KEY to a real key from https://dashboard.stripe.com/test/apikeys (starts with sk_test_…), then restart the server.",
    });
  }

  const productId = req.body?.productId;
  const quantity = Math.max(1, Math.min(10, Number(req.body?.quantity) || 1));

  const product = getProduct(productId);
  if (!product) {
    return res.status(400).json({ error: "Unknown product" });
  }

  // Create pending order first so we have a stable orderRef in metadata
  let order;
  try {
    order = createPendingOrder({
      productId: product.id,
      productName: product.name,
      quantity,
      unitAmountPence: product.pricePence,
      currency: product.currency,
      stripeSessionId: null,
    });
  } catch (err) {
    console.error("[orders] create pending failed:", err);
    return res.status(500).json({ error: "Could not create order" });
  }

  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [
        {
          quantity,
          price_data: {
            currency: product.currency,
            unit_amount: product.pricePence,
            product_data: {
              name: product.name,
              description: product.description,
              metadata: {
                productId: product.id,
              },
            },
          },
        },
      ],
      success_url: `${BASE_URL}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${BASE_URL}/cancel.html?product=${encodeURIComponent(product.id)}`,
      customer_email: undefined,
      billing_address_collection: "auto",
      metadata: {
        orderRef: order.orderRef,
        orderId: order.id,
        productId: product.id,
        productName: product.name,
        quantity: String(quantity),
        unitAmountPence: String(product.pricePence),
      },
      payment_intent_data: {
        metadata: {
          orderRef: order.orderRef,
          productId: product.id,
        },
      },
    });

    updateOrder(order.id, { stripeSessionId: session.id });

    res.json({
      url: session.url,
      sessionId: session.id,
      orderRef: order.orderRef,
    });
  } catch (err) {
    console.error("[stripe] create session failed:", err.message);
    updateOrder(order.id, { status: "checkout_failed", error: err.message });

    let userError = "Could not start checkout. Check the server log for details.";
    if (/Invalid API Key/i.test(err.message)) {
      userError =
        "Stripe rejected the API key. Replace STRIPE_SECRET_KEY in .env with a real test key from https://dashboard.stripe.com/test/apikeys and restart npm start.";
    } else if (/No such/i.test(err.message)) {
      userError = err.message;
    }

    res.status(500).json({ error: userError });
  }
});

/**
 * Optional: read-only order lookup for the success page (no secrets).
 * Does not mark paid — webhook is the source of truth.
 */
app.get("/api/orders/by-session/:sessionId", async (req, res) => {
  if (!stripe) {
    return res.status(503).json({ error: "Stripe not configured" });
  }

  try {
    const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
    res.json({
      paymentStatus: session.payment_status,
      orderRef: session.metadata?.orderRef || null,
      productName: session.metadata?.productName || null,
      quantity: session.metadata?.quantity || null,
      amountTotal: session.amount_total,
      currency: session.currency,
      customerEmail: session.customer_details?.email || session.customer_email || null,
    });
  } catch (err) {
    res.status(404).json({ error: "Session not found" });
  }
});

// Static site
app.use(express.static(rootDir, { extensions: ["html"] }));

app.listen(PORT, () => {
  console.log(`Tyneside Cleaning listening on ${BASE_URL} (port ${PORT})`);
  console.log(`  Home:     ${BASE_URL}/`);
  console.log(`  Booking:  ${BASE_URL}/book.html`);
  console.log(`  Checkout: POST /api/create-checkout-session (legacy store pages)`);
  console.log(`  Webhook:  POST /api/webhooks/stripe`);
});
