/**
 * Tyneside Cleaning — booking configuration
 * -----------------------------------------
 * Google Calendar credentials (same project as business/booking-system).
 * Leave googleApiKey empty to run in demo mode.
 *
 * Setup: see booking README notes in the site README, or business/booking-system/README.md
 */
const CONFIG = {
  // --- Google Calendar (required for live sync) ---
  googleApiKey: "AIzaSyD3rs9jjwI37upr6lcUVamMxdB_7BOGFio",

  // Calendar ID: usually Gmail, or Calendar Settings → Integrate calendar → Calendar ID
  // Calendar must be "Make available to public" (free/busy or full details).
  calendarId: "reevemarakkalsherry@gmail.com",

  // Owner email — invited when visitors book so the clean lands on the host calendar.
  ownerEmail: "reevemarakkalsherry@gmail.com",

  ownerName: "Tyneside Cleaning",
  businessName: "Book a clean",
  businessDescription:
    "Pick a free green slot. Busy times from our calendar are blocked automatically.",

  // Optional OAuth Web Client ID — real event create + invite.
  // Without it, bookings open a pre-filled Google Calendar template link.
  googleClientId: "",

  // --- Availability (tuned for cleaning visits) ---
  slotDurationMinutes: 120,
  // 0 = Sunday … 6 = Saturday
  businessDays: [1, 2, 3, 4, 5, 6], // Mon–Sat
  businessHours: {
    start: "08:00",
    end: "18:00",
  },
  bookingWindowDays: 28,
  minNoticeHours: 24,

  // IANA zone, or "" for browser local
  timeZone: "Europe/London",

  refreshIntervalMs: 5 * 60 * 1000,

  hideEventDetails: true,

  // Cleaning-specific labels (used by app.js)
  eventSummaryPrefix: "Cleaning for",
  bookingNoun: "clean",
};
