# Tyneside Cleaning

**Reliable cleans on Tyneside — book a free slot online.**

Site for [tyneside.cleaning](https://tyneside.cleaning) with a **Google Calendar booking** flow integrated from `business/booking-system`.

---

## What’s included

| Page | Purpose |
|------|---------|
| `index.html` | Cleaning marketing home (`theme-cleaning`) |
| `book.html` | Live availability calendar + book a clean |
| `booking/config.js` | Calendar API key, hours, branding |
| `booking/app.js` | Sync, free slots, booking, cancel |
| `booking/booking.css` | Calendar UI skinned to the cleaning theme |
| `layout.css` / `themes.css` | Shared Tyneside design system |

Legacy ThinkPad / Stripe store pages (`thinkpad-t14s.html`, checkout API) remain from the Technology template if you still need them; the primary product for this app is **booking**.

---

## Booking behaviour

1. Loads busy times from a **public Google Calendar** (API key).  
2. Generates **green free slots** only inside business hours and outside those events.  
3. Guest books with name, email, optional address/notes.  
4. Slot is stored in `localStorage` and opens a **Google Calendar** template (or creates a real event if OAuth client ID is set).  
5. Pending bookings on this browser can be cancelled; cancelled slots free up again.

Without `googleApiKey`, the page runs in **demo mode** with sample busy blocks.

### Cleaning-tuned defaults (`booking/config.js`)

| Setting | Default |
|---------|---------|
| Slot length | 120 minutes |
| Days | Mon–Sat |
| Hours | 08:00–18:00 |
| Window | 28 days ahead |
| Min notice | 24 hours |
| Time zone | `Europe/London` |

---

## Run locally

```bash
cd tyneside.technology-main
npm install
npm start
```

Open:

- Home: http://localhost:3000/  
- Book: http://localhost:3000/book.html  
- Health: http://localhost:3000/api/health  

Static-only (no Node):

```bash
npx serve .
# or: python -m http.server 8080
```

Google Calendar API calls need `http://` or `https://` (not `file://`).

---

## Connect Google Calendar

Same steps as `business/booking-system/README.md`:

1. Enable **Google Calendar API** in Google Cloud.  
2. Create an **API key**, restrict to Calendar API + your domain referrers.  
3. Make the calendar public (prefer **free/busy**).  
4. Put `googleApiKey`, `calendarId`, and `ownerEmail` in `booking/config.js`.  
5. Optional: set `googleClientId` for in-app event create + invites.

Current config reuses the credentials from the standalone booking system; adjust if the cleaning calendar should be separate.

---

## Design

Body class:

```html
<body class="site theme-cleaning">
```

On the book page:

```html
<body class="site theme-cleaning booking-page">
```

Teal / light skin from `themes.css`; booking chrome in `booking/booking.css` uses the same CSS variables.

---

## Family sites

- [tyneside.software](https://tyneside.software/)  
- [tyneside.cleaning](https://tyneside.cleaning/)  
- [tyneside.charity](https://tyneside.charity/)  
- [tyneside.group](https://tyneside.group/)  
- [tyneside.technology](https://tyneside.technology/)  
- [tyneside.games](https://tyneside.games/)  

Contact: WhatsApp **+44 7411 949215** · Howden Community Hub.

---

Proudly made on the banks of the Tyne.
